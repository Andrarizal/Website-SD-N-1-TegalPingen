@auth
<h5>Login As Admin</h5>
<a href="{{route('logout')}}">Logut</a>
<a href="{{route('admin.profile-show')}}">profile</a>
@endauth