@auth

<h5>Login As SUPER Admin</h5>
<a href="{{route('logout')}}">Logut</a>
<a href="{{route('super.profile-show')}}">Profile</a>
<a href="{{route('aViewSarana')}}">Sarana & Prasarana</a>
<a href="{{route('aViewBerita')}}">Berita</a>
<a href="{{route('aViewAdmin')}}">ADmin_List</a>
@endauth