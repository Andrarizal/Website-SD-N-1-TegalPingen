@auth
    <form class="m-3" action="/t3g4l/superministrator/sarana/change/{{$sarana->id}}" method="post">
            @method('put')
            @csrf
            <div class="form-group">
               <label for="title">Nama Sarana & Prasarana</label>
               <input type="text" class="form-control" name="title" id="title" placeholder="Masukan Nama" value="{{$sarana->title}}" required>
            </div>
            <div class="form-group">
               <label for="desc">Deskripsi</label>
               <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3">{{$sarana->deskripsi}}</textarea>
            </div>            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    @endauth    