<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class ManageAdmin extends Controller
{
    /*
    =============
    SUPER ADMIN
    =============
    */
    public function superViewAdmin() {
        $select = new user;
        $data['pick'] = $select::all();
        return view('tegal.super.admin-list.viewAdmin', $data);
        //return view('home.admin.sarana.viewSarana');
    }

    public function superAddAdmin() {
        return view('tegal.super.admin-list.addAdmin');

    }

    public function superSubmitAdmin(Request $request) {

        ///ddd($request);
        $validated = $request->validate([
            'name' => 'required|min:10',
            'username' => 'required|unique:users,username|min:5',
            'email' => 'required|email:rfc,dns|unique:users,email',
            'password' => 'required|min:8',
            'password_confirmation' => 'required|same:password'
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:5048',
        ]); 
        $imageName = time().'.'.$request->image->extension(); 
        $request->image->move(public_path('images'), $imageName);

        $berita = berita::create([
            'title' => $request->title,
            'deskripsi' => $request->deskripsi,
            'carosel' => $request->carosel,
            'image' => $imageName,
        ]);

        return redirect() -> route('aViewBerita') -> with('success', "Data Berhasil Ditambah");

    }


     public function superUpdateAdmin($id) {

        $data['berita'] = berita::find($id);
        return view('tegal.super.admin-list.updateBerita', $data);

    }

     public function superChangeAdmin(Request $request, $id) 
    {
        //ddd($request);
        $update = berita::find($id);
        $update->title = request('title');
        $update->deskripsi = request('deskripsi');
        $update->carosel = request('carosel');
        $update->save();

        return redirect() -> route('aViewBerita') -> with('success', "Data Berhasil Terubah");
    }


    public function superDeleteAdmin($id){
        
        $pick = berita::find($id);
        $pick->delete();

        return redirect() -> back() -> with('success', "Data Berhasil Dihapus");
    }
}
