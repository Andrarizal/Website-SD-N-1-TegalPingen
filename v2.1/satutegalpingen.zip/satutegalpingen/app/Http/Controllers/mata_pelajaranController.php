<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class mata_pelajaranController extends Controller
{
    //
}
