<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class guru_mapelController extends Controller
{
    //
}
