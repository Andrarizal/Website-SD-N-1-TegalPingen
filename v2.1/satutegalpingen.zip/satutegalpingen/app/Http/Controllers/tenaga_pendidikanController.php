<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class tenaga_pendidikanController extends Controller
{
    //
}
