
<?php $__env->startSection('content'); ?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Title</th>
      <th scope="col">Deskripsi</th>
      <th scope="col">Carousel</th>
      <th scope="col">Dibuat Saat</th>
      <th scope="col">Diubah Saat</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
      <td>@mdo</td>
      <td>@mdo</td>
      <td>@mdo</td>
    </tr>
    
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tegal.layout.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/admin/berita/beritaAdmin.blade.php ENDPATH**/ ?>