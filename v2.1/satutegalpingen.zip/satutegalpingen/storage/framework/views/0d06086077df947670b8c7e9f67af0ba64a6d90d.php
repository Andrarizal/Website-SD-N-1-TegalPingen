<?php if(auth()->guard()->check()): ?>
    <form class="m-3" action="/t3g4l/superministrator/berita/change/<?php echo e($berita->id); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <label for="title">Nama Berita</label>
               <input type="text" class="form-control" name="title" id="title" placeholder="Masukan Nama" value="<?php echo e($berita->title); ?>" required>
            </div>
            <div class="form-group">
               <label for="desc">Deskripsi</label>
               <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3"><?php echo e($berita->deskripsi); ?></textarea>
            </div>    
            <div class="form-group">
               <label for="carosel">Muncul Carousel</label>
               <select class="form-control" id="carosel" name="carosel">
                  <option>yes</option>
                  <option>no</option>
               </select>
            </div>        
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    <?php endif; ?>    <?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/super/berita/updateBerita.blade.php ENDPATH**/ ?>