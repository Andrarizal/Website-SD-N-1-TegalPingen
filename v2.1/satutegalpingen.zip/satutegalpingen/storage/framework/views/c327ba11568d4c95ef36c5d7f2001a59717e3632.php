<?php if(auth()->guard()->check()): ?>

<h5>Login As SUPER Admin</h5>
<a href="<?php echo e(route('logout')); ?>">Logut</a>
<a href="<?php echo e(route('super.profile-show')); ?>">Profile</a>
<a href="<?php echo e(route('aViewSarana')); ?>">Sarana & Prasarana</a>
<a href="<?php echo e(route('aViewBerita')); ?>">Berita</a>
<?php endif; ?><?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/super/index_super.blade.php ENDPATH**/ ?>