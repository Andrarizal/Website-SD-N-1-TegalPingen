<?php if(auth()->guard()->check()): ?>
    <form class="m-3" action="/t3g4l/superministrator/sarana/change/<?php echo e($sarana->id); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <label for="title">Nama Sarana & Prasarana</label>
               <input type="text" class="form-control" name="title" id="title" placeholder="Masukan Nama" value="<?php echo e($sarana->title); ?>" required>
            </div>
            <div class="form-group">
               <label for="desc">Deskripsi</label>
               <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3"><?php echo e($sarana->deskripsi); ?></textarea>
            </div>            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    <?php endif; ?>    <?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/super/sarana/updateSarana.blade.php ENDPATH**/ ?>