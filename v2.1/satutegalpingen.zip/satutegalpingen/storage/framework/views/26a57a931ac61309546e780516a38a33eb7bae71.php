<?php if(auth()->guard()->check()): ?>
        <table class="table">
			<thead>
				<tr>
					<th scope="col">ID</th>
					<th scope="col">Nama Sarana & Prasarana</th>
					<th scope="col">Img</th>
					<th scope="col">Deskripsi</th>
					<th scope="col">Dibuat</th>
					<th scope="col">Terbarui</th>
					<th scope="col">AKSI</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $pick; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($p->id); ?></th>
						<td><?php echo e($p->title); ?></td>
						<td><img src="<?php echo url('images/'.$p->image.''); ?>" style="width:50%; height: 50%;"></td>
						<td><?php echo e($p->deskripsi); ?></td>
						<td><?php echo e($p->created_at); ?></td>
						<td><?php echo e($p->updated_at); ?></td>
						<td><a href="<?php echo e(url('/t3g4l/superministrator/sarana/update/'.$p->id.'')); ?>" class="btn btn-secondary">Update</a>   
						<form action="<?php echo e(url('/t3g4l/superministrator/sarana/delete/'.$p->id.'')); ?>"  method="post">
							<?php echo method_field('delete'); ?>
							<?php echo csrf_field(); ?>
							<button type="submit" class="btn btn-danger">Delete</button>
						</form>
					</tr></td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<a href="<?php echo e(route('super.add-sarana')); ?>" class="btn btn-primary">add Data</a>
    <?php endif; ?>
    <?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/super/sarana/viewSarana.blade.php ENDPATH**/ ?>