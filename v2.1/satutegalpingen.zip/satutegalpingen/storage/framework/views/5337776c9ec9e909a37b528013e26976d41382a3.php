<?php if(auth()->guard()->check()): ?>
<form action="/t3g4l/superministrator/update-profile-send/<?php echo e(Auth::user()->id); ?>" method="post">
	<?php echo method_field('put'); ?>
	<?php echo csrf_field(); ?>
	<label for="username">Username</label>
	<input type="text" name="username" value="<?php echo e(Auth::user()->username); ?>">

	<label for="name">Name</label>
	<input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">

	<label for="email">Email</label>
	<input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>">

	<button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php endif; ?><?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/super/updateSuper.blade.php ENDPATH**/ ?>