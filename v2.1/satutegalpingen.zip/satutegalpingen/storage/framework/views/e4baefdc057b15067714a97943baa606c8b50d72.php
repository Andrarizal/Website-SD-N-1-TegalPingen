<?php if(auth()->guard()->check()): ?>
<table>
	<thead>
		<th>Username</th>
		<th>Name</th>
		<th>Email</th>
		<th>Aksi</th>
	</thead>
	<tbody>
		<tr>
			<td><h5><?php echo e(Auth::user()->username); ?></h5></td>
			<td><h5><?php echo e(Auth::user()->name); ?></h5></td>
			<td><h5><?php echo e(Auth::user()->email); ?></h5></td>
			<td><a href="<?php echo e(route('super.profile-update')); ?>">Update</a></td>
		</tr>
	</tbody>
</table>
<?php endif; ?><?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/super/profileSuper.blade.php ENDPATH**/ ?>