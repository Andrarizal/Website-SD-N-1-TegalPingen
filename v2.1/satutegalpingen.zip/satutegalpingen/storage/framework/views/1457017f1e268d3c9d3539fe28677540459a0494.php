<?php if(auth()->guard()->check()): ?>
<h5>Login As Admin</h5>
<a href="<?php echo e(route('logout')); ?>">Logut</a>
<a href="<?php echo e(route('admin.profile-show')); ?>">profile</a>
<?php endif; ?><?php /**PATH D:\laragon\www\satutegalpingen\resources\views/tegal/admin/index_admin.blade.php ENDPATH**/ ?>